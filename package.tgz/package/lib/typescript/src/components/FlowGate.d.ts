import type { GateProps } from '../types';
export declare function Gate({ children, when, showWhenIdle, showWhenActive, showWhenFinished, }: GateProps): import("react").ReactNode;
//# sourceMappingURL=FlowGate.d.ts.map