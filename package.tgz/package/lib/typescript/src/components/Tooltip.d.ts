import type { TooltipProps } from '../types';
export default function Tooltip({ config, measure }: TooltipProps): import("react").JSX.Element;
//# sourceMappingURL=Tooltip.d.ts.map