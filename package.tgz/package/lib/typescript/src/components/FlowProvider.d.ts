import type { ProviderProps } from '../types';
export declare function FlowProvider<TData extends Record<string, unknown> = Record<string, unknown>>({ children, steps, ...options }: ProviderProps<TData>): import("react").JSX.Element;
//# sourceMappingURL=FlowProvider.d.ts.map