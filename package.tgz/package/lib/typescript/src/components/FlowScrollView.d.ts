import { type FlowScrollViewProps } from '../types';
export declare function FlowScrollView({ children, onScroll, scrollEventThrottle, ref, horizontal, ...props }: FlowScrollViewProps): import("react").JSX.Element;
//# sourceMappingURL=FlowScrollView.d.ts.map