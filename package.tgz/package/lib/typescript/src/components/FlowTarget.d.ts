import React from 'react';
import type { TargetProps } from '../types';
export declare function Target({ step, spotlight, tooltip, onOverlayPress, children, onActive, }: TargetProps): string | number | bigint | boolean | Iterable<React.ReactNode> | Promise<string | number | bigint | boolean | React.ReactPortal | React.ReactElement<unknown, string | React.JSXElementConstructor<any>> | Iterable<React.ReactNode> | null | undefined> | React.JSX.Element | null | undefined;
//# sourceMappingURL=FlowTarget.d.ts.map