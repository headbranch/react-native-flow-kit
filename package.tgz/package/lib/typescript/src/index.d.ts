import { FlowProvider } from './components/FlowProvider';
import { FlowScrollView } from './components/FlowScrollView';
import { Gate } from './components/FlowGate';
import { Target } from './components/FlowTarget';
import { useFlow } from './hooks/useFlow';
export declare const Flow: {
    Provider: typeof FlowProvider;
    Target: typeof Target;
    Gate: typeof Gate;
    ScrollView: typeof FlowScrollView;
    useFlow: typeof useFlow;
};
export { useFlow };
export type { ProviderProps, TargetProps, StepRef, SpotlightConfig, TooltipConfig, UseFlowReturn, GateProps, FlowStatus, } from './types';
//# sourceMappingURL=index.d.ts.map