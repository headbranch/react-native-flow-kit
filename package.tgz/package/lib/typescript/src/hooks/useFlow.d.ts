import type { UseFlowReturn } from '../types';
export declare function useFlow<TData extends Record<string, unknown> = Record<string, unknown>>(): UseFlowReturn<TData>;
//# sourceMappingURL=useFlow.d.ts.map