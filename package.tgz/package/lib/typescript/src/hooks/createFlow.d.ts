import type { FlowOptions, UseFlowReturn } from '../types';
export declare function createFlow<TData extends Record<string, unknown> = Record<string, unknown>>({ steps, initialData, autoStart, onFinish, onStart, onStepChange, }: FlowOptions<TData>): UseFlowReturn<TData>;
//# sourceMappingURL=createFlow.d.ts.map