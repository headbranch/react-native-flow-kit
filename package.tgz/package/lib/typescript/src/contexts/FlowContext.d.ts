import type { UseFlowReturn } from '../types';
export declare const FlowContext: import("react").Context<UseFlowReturn<any> | null>;
export declare function useFlowContext(componentName: string): UseFlowReturn<any>;
//# sourceMappingURL=FlowContext.d.ts.map