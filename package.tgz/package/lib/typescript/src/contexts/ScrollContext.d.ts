import type { ScrollContextValue } from '../types';
export declare const ScrollContext: import("react").Context<ScrollContextValue | null>;
//# sourceMappingURL=ScrollContext.d.ts.map