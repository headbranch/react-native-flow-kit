export default function mergeRefs<T>(...refs: any[]): (value: T) => void;
//# sourceMappingURL=mergeRefs.d.ts.map