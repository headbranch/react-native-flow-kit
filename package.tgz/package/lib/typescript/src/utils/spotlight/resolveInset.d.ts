import type { SpotlightConfig } from '../../types';
export default function resolveInset(inset: SpotlightConfig['inset']): {
    x: number;
    y: number;
};
//# sourceMappingURL=resolveInset.d.ts.map