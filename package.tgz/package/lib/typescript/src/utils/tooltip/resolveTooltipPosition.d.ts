import type { ElementRect, TooltipAlign, TooltipSide } from '../../types';
export default function resolveTooltipPosition(measure: ElementRect, side: TooltipSide, gap: number, align?: TooltipAlign, tooltipHeight?: number, tooltipWidth?: number): {
    top?: number;
    bottom?: number;
    left?: number;
    right?: number;
};
//# sourceMappingURL=resolveTooltipPosition.d.ts.map