import { type ElementRect, type TooltipSide } from '../../types';
export default function autoPickSide(measure: ElementRect): TooltipSide;
//# sourceMappingURL=autoPickSide.d.ts.map