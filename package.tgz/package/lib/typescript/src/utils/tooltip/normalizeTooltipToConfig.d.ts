import { type ReactNode } from 'react';
import { type TooltipConfig } from '../../types';
export default function normalizeTooltipToConfig(tooltip: TooltipConfig | ReactNode): TooltipConfig | undefined;
//# sourceMappingURL=normalizeTooltipToConfig.d.ts.map